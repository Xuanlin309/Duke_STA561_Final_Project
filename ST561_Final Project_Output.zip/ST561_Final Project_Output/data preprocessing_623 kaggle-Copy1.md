

```python
import numpy as np 
import pandas as pd
```


```python
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
```


```python
train.head(5)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>Alley</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>...</th>
      <th>PoolArea</th>
      <th>PoolQC</th>
      <th>Fence</th>
      <th>MiscFeature</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>60</td>
      <td>RL</td>
      <td>65.0</td>
      <td>8450</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>208500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>20</td>
      <td>RL</td>
      <td>80.0</td>
      <td>9600</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>5</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>181500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>60</td>
      <td>RL</td>
      <td>68.0</td>
      <td>11250</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>9</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>223500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>70</td>
      <td>RL</td>
      <td>60.0</td>
      <td>9550</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2006</td>
      <td>WD</td>
      <td>Abnorml</td>
      <td>140000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>60</td>
      <td>RL</td>
      <td>84.0</td>
      <td>14260</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>...</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>12</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 81 columns</p>
</div>




```python
#check the numbers of samples and features
print("The train data size before dropping Id feature is : {} ".format(train.shape))
print("The test data size before dropping Id feature is : {} ".format(test.shape))

#Save the 'Id' column
train_ID = train['Id']
test_ID = test['Id']

#Now drop the  'Id' colum since it's unnecessary for  the prediction process.
train.drop("Id", axis = 1, inplace = True)
test.drop("Id", axis = 1, inplace = True)

#check again the data size after dropping the 'Id' variable
print("\nThe train data size after dropping Id feature is : {} ".format(train.shape)) 
print("The test data size after dropping Id feature is : {} ".format(test.shape))
```

    The train data size before dropping Id feature is : (1460, 81) 
    The test data size before dropping Id feature is : (1459, 80) 
    
    The train data size after dropping Id feature is : (1460, 80) 
    The test data size after dropping Id feature is : (1459, 79) 



```python
%matplotlib inline
import matplotlib.pyplot as plt  
import seaborn as sns
color = sns.color_palette()
sns.set_style('darkgrid')
import warnings
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn
```


```python
# outliners
fig, ax = plt.subplots()
ax.scatter(x = train['GrLivArea'], y = train['SalePrice'])
plt.ylabel('SalePrice', fontsize=13)
plt.xlabel('GrLivArea', fontsize=13)
plt.show()
```


![png](output_5_0.png)



```python
#Deleting outliers
train = train.drop(train[(train['GrLivArea']>4000) & (train['SalePrice']<300000)].index)
# extremely large areas for very low prices
#Check the graphic again
fig, ax = plt.subplots()
ax.scatter(train['GrLivArea'], train['SalePrice'])
plt.ylabel('SalePrice', fontsize=13)
plt.xlabel('GrLivArea', fontsize=13)
plt.show()
```


![png](output_6_0.png)



```python
from scipy import stats
from scipy.stats import norm, skew
sns.distplot(train['SalePrice'] , fit=norm);

# Get the fitted parameters used by the function
(mu, sigma) = norm.fit(train['SalePrice'])
print( '\n mu = {:.2f} and sigma = {:.2f}\n'.format(mu, sigma))

#Now plot the distribution
plt.legend(['Normal dist. ($\mu=$ {:.2f} and $\sigma=$ {:.2f} )'.format(mu, sigma)],
            loc='best')
plt.ylabel('Frequency')
plt.title('SalePrice distribution')

#Get also the QQ-plot
fig = plt.figure()
res = stats.probplot(train['SalePrice'], plot=plt)
plt.show()
```

    
     mu = 180932.92 and sigma = 79467.79
    



![png](output_7_1.png)



![png](output_7_2.png)



```python
# The target variable is right skewed
#Log-transformation of the target variable
train["SalePrice"] = np.log1p(train["SalePrice"])

#Check the new distribution 
sns.distplot(train['SalePrice'] , fit=norm);

# Get the fitted parameters used by the function
(mu, sigma) = norm.fit(train['SalePrice'])
print( '\n mu = {:.2f} and sigma = {:.2f}\n'.format(mu, sigma))

#Now plot the distribution
plt.legend(['Normal dist. ($\mu=$ {:.2f} and $\sigma=$ {:.2f} )'.format(mu, sigma)],
            loc='best')
plt.ylabel('Frequency')
plt.title('SalePrice distribution')

#Get also the QQ-plot
fig = plt.figure()
res = stats.probplot(train['SalePrice'], plot=plt)
plt.show()
```

    
     mu = 12.02 and sigma = 0.40
    



![png](output_8_1.png)



![png](output_8_2.png)



```python
# feature engineering
ntrain = train.shape[0]
ntest = test.shape[0]
y_train = train.SalePrice.values
all_data = pd.concat((train, test)).reset_index(drop=True)
all_data.drop(['SalePrice'], axis=1, inplace=True)
print("all_data size is : {}".format(all_data.shape))
```

    all_data size is : (2917, 79)



```python
all_data_na = (all_data.isnull().sum() / len(all_data)) * 100
all_data_na = all_data_na.drop(all_data_na[all_data_na == 0].index).sort_values(ascending=False)[:30]
missing_data = pd.DataFrame({'Missing Ratio' :all_data_na})
missing_data.head(20)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Missing Ratio</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>PoolQC</th>
      <td>99.691464</td>
    </tr>
    <tr>
      <th>MiscFeature</th>
      <td>96.400411</td>
    </tr>
    <tr>
      <th>Alley</th>
      <td>93.212204</td>
    </tr>
    <tr>
      <th>Fence</th>
      <td>80.425094</td>
    </tr>
    <tr>
      <th>FireplaceQu</th>
      <td>48.680151</td>
    </tr>
    <tr>
      <th>LotFrontage</th>
      <td>16.660953</td>
    </tr>
    <tr>
      <th>GarageQual</th>
      <td>5.450806</td>
    </tr>
    <tr>
      <th>GarageCond</th>
      <td>5.450806</td>
    </tr>
    <tr>
      <th>GarageFinish</th>
      <td>5.450806</td>
    </tr>
    <tr>
      <th>GarageYrBlt</th>
      <td>5.450806</td>
    </tr>
    <tr>
      <th>GarageType</th>
      <td>5.382242</td>
    </tr>
    <tr>
      <th>BsmtExposure</th>
      <td>2.811107</td>
    </tr>
    <tr>
      <th>BsmtCond</th>
      <td>2.811107</td>
    </tr>
    <tr>
      <th>BsmtQual</th>
      <td>2.776826</td>
    </tr>
    <tr>
      <th>BsmtFinType2</th>
      <td>2.742544</td>
    </tr>
    <tr>
      <th>BsmtFinType1</th>
      <td>2.708262</td>
    </tr>
    <tr>
      <th>MasVnrType</th>
      <td>0.822763</td>
    </tr>
    <tr>
      <th>MasVnrArea</th>
      <td>0.788481</td>
    </tr>
    <tr>
      <th>MSZoning</th>
      <td>0.137127</td>
    </tr>
    <tr>
      <th>BsmtFullBath</th>
      <td>0.068564</td>
    </tr>
  </tbody>
</table>
</div>




```python
f, ax = plt.subplots(figsize=(15, 12))
plt.xticks(rotation='90')
sns.barplot(x=all_data_na.index, y=all_data_na)
plt.xlabel('Features', fontsize=15)
plt.ylabel('Percent of missing values', fontsize=15)
plt.title('Percent missing data by feature', fontsize=15)
```




    <matplotlib.text.Text at 0x11948f250>




![png](output_11_1.png)



```python
#Correlation map to see how features are correlated with SalePrice
corrmat = train.corr()
plt.subplots(figsize=(12,9))
sns.heatmap(corrmat, vmax=0.9, square=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x119419ad0>




![png](output_12_1.png)



```python
# imputation
# no features imputate none
all_data["PoolQC"] = all_data["PoolQC"].fillna("None")
all_data["MiscFeature"] = all_data["MiscFeature"].fillna("None")
all_data["Alley"] = all_data["Alley"].fillna("None")
all_data["Fence"] = all_data["Fence"].fillna("None")
all_data["FireplaceQu"] = all_data["FireplaceQu"].fillna("None")
```


```python
#Group by neighborhood and fill in missing value by the median LotFrontage of all the neighborhood
all_data["LotFrontage"] = all_data.groupby("Neighborhood")["LotFrontage"].transform(
    lambda x: x.fillna(x.median()))
```


```python
for col in ('GarageType', 'GarageFinish', 'GarageQual', 'GarageCond'):
    all_data[col] = all_data[col].fillna('None')
```


```python
for col in ('GarageYrBlt', 'GarageArea', 'GarageCars'):
    all_data[col] = all_data[col].fillna(0)
```


```python
for col in ('BsmtFinSF1', 'BsmtFinSF2', 'BsmtUnfSF','TotalBsmtSF', 'BsmtFullBath', 'BsmtHalfBath'):
    all_data[col] = all_data[col].fillna(0)
```


```python
for col in ('BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2'):
    all_data[col] = all_data[col].fillna('None')
```


```python
all_data["MasVnrType"] = all_data["MasVnrType"].fillna("None")
all_data["MasVnrArea"] = all_data["MasVnrArea"].fillna(0)
```


```python
#MSZoning (The general zoning classification) : 'RL' is by far the most common value. So we can fill in missing values with 'RL'
# histogram
all_data['MSZoning'] = all_data['MSZoning'].fillna(all_data['MSZoning'].mode()[0])
```


```python
#Utilities : For this categorical feature all records are "AllPub", except for one "NoSeWa" and 2 NA . Since the house with 'NoSewa' is in the training set, 
# this feature won't help in predictive modelling. We can then safely remove it.
# histogram
all_data = all_data.drop(['Utilities'], axis=1)
```


```python
#Functional : data description says NA means typical
all_data["Functional"] = all_data["Functional"].fillna("Typ")
```


```python
#Electrical : It has one NA value. Since this feature has mostly 'SBrkr', we can set that for the missing value.
all_data['Electrical'] = all_data['Electrical'].fillna(all_data['Electrical'].mode()[0])
```


```python
#KitchenQual: Only one NA value, and same as Electrical, we set 'TA' (which is the most frequent) 
#for the missing value in KitchenQual
all_data['KitchenQual'] = all_data['KitchenQual'].fillna(all_data['KitchenQual'].mode()[0])
```


```python
#Exterior1st and Exterior2nd : Again Both Exterior 1 & 2 have only one missing value. 
#We will just substitute in the most common string
all_data['Exterior1st'] = all_data['Exterior1st'].fillna(all_data['Exterior1st'].mode()[0])
all_data['Exterior2nd'] = all_data['Exterior2nd'].fillna(all_data['Exterior2nd'].mode()[0])
```


```python
#SaleType : Fill in again with most frequent which is "WD"
all_data['SaleType'] = all_data['SaleType'].fillna(all_data['SaleType'].mode()[0])
```


```python
#MSSubClass : Na most likely means No building class. We can replace missing values with None
all_data['MSSubClass'] = all_data['MSSubClass'].fillna("None")
```


```python
#Check remaining missing values if any 
all_data_na = (all_data.isnull().sum() / len(all_data)) * 100
all_data_na = all_data_na.drop(all_data_na[all_data_na == 0].index).sort_values(ascending=False)
missing_data = pd.DataFrame({'Missing Ratio' :all_data_na})
missing_data.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Missing Ratio</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
#Transforming some numerical variables that are really categorical
#MSSubClass=The building class
all_data['MSSubClass'] = all_data['MSSubClass'].apply(str)

#Changing OverallCond into a categorical variable
all_data['OverallCond'] = all_data['OverallCond'].astype(str)

#Year and month sold are transformed into categorical features.
all_data['YrSold'] = all_data['YrSold'].astype(str)
all_data['MoSold'] = all_data['MoSold'].astype(str)
```


```python
#Label Encoding some categorical variables that may contain information in their ordering set
from sklearn.preprocessing import LabelEncoder
cols = ('FireplaceQu', 'BsmtQual', 'BsmtCond', 'GarageQual', 'GarageCond', 
        'ExterQual', 'ExterCond','HeatingQC', 'PoolQC', 'KitchenQual', 'BsmtFinType1', 
        'BsmtFinType2', 'Functional', 'Fence', 'BsmtExposure', 'GarageFinish', 'LandSlope',
        'LotShape', 'PavedDrive', 'Street', 'Alley', 'CentralAir', 'MSSubClass', 'OverallCond', 
        'YrSold', 'MoSold')
# process columns, apply LabelEncoder to categorical features
for c in cols:
    lbl = LabelEncoder() 
    lbl.fit(list(all_data[c].values)) 
    all_data[c] = lbl.transform(list(all_data[c].values))

# shape        
print('Shape all_data: {}'.format(all_data.shape))
```

    Shape all_data: (2917, 78)



```python
all_data[['FireplaceQu', 'BsmtQual', 'BsmtCond', 'GarageQual', 'GarageCond', 
        'ExterQual', 'ExterCond','HeatingQC', 'PoolQC', 'KitchenQual', 'BsmtFinType1', 
        'BsmtFinType2', 'Functional', 'Fence', 'BsmtExposure', 'GarageFinish', 'LandSlope',
        'LotShape', 'PavedDrive', 'Street', 'Alley', 'CentralAir', 'MSSubClass', 'OverallCond', 
        'YrSold', 'MoSold']].head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>FireplaceQu</th>
      <th>BsmtQual</th>
      <th>BsmtCond</th>
      <th>GarageQual</th>
      <th>GarageCond</th>
      <th>ExterQual</th>
      <th>ExterCond</th>
      <th>HeatingQC</th>
      <th>PoolQC</th>
      <th>KitchenQual</th>
      <th>...</th>
      <th>LandSlope</th>
      <th>LotShape</th>
      <th>PavedDrive</th>
      <th>Street</th>
      <th>Alley</th>
      <th>CentralAir</th>
      <th>MSSubClass</th>
      <th>OverallCond</th>
      <th>YrSold</th>
      <th>MoSold</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>2</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>10</td>
      <td>4</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>...</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>5</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>10</td>
      <td>4</td>
      <td>2</td>
      <td>11</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>4</td>
      <td>1</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>11</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>10</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
#Adding one more important feature
# Adding total sqfootage feature 
all_data['TotalSF'] = all_data['TotalBsmtSF'] + all_data['1stFlrSF'] + all_data['2ndFlrSF']
```


```python
# schewed feature
numeric_feats = all_data.dtypes[all_data.dtypes != "object"].index

# Check the skew of all numerical features
skewed_feats = all_data[numeric_feats].apply(lambda x: skew(x.dropna())).sort_values(ascending=False)
print("\nSkew in numerical features: \n")
skewness = pd.DataFrame({'Skew' :skewed_feats})
skewness.head(10)
```

    
    Skew in numerical features: 
    





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Skew</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>MiscVal</th>
      <td>21.939672</td>
    </tr>
    <tr>
      <th>PoolArea</th>
      <td>17.688664</td>
    </tr>
    <tr>
      <th>LotArea</th>
      <td>13.109495</td>
    </tr>
    <tr>
      <th>LowQualFinSF</th>
      <td>12.084539</td>
    </tr>
    <tr>
      <th>3SsnPorch</th>
      <td>11.372080</td>
    </tr>
    <tr>
      <th>LandSlope</th>
      <td>4.973254</td>
    </tr>
    <tr>
      <th>KitchenAbvGr</th>
      <td>4.300550</td>
    </tr>
    <tr>
      <th>BsmtFinSF2</th>
      <td>4.144503</td>
    </tr>
    <tr>
      <th>EnclosedPorch</th>
      <td>4.002344</td>
    </tr>
    <tr>
      <th>ScreenPorch</th>
      <td>3.945101</td>
    </tr>
  </tbody>
</table>
</div>




```python
for col in numeric_feats:
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    plt.hist(all_data[col], bins=50)
    plt.title("Histogram of value counts for {}".format(col))
    plt.ylabel('Number of IDs')
    plt.xlabel('Occurences of value for ID')
    plt.show()
```


![png](output_34_0.png)



![png](output_34_1.png)



![png](output_34_2.png)



![png](output_34_3.png)



![png](output_34_4.png)



![png](output_34_5.png)



![png](output_34_6.png)



![png](output_34_7.png)



![png](output_34_8.png)



![png](output_34_9.png)



![png](output_34_10.png)



![png](output_34_11.png)



![png](output_34_12.png)



![png](output_34_13.png)



![png](output_34_14.png)



![png](output_34_15.png)



![png](output_34_16.png)



![png](output_34_17.png)



![png](output_34_18.png)



![png](output_34_19.png)



![png](output_34_20.png)



![png](output_34_21.png)



![png](output_34_22.png)



![png](output_34_23.png)



![png](output_34_24.png)



![png](output_34_25.png)



![png](output_34_26.png)



![png](output_34_27.png)



![png](output_34_28.png)



![png](output_34_29.png)



![png](output_34_30.png)



![png](output_34_31.png)



![png](output_34_32.png)



![png](output_34_33.png)



![png](output_34_34.png)



![png](output_34_35.png)



![png](output_34_36.png)



![png](output_34_37.png)



![png](output_34_38.png)



![png](output_34_39.png)



![png](output_34_40.png)



![png](output_34_41.png)



![png](output_34_42.png)



![png](output_34_43.png)



![png](output_34_44.png)



![png](output_34_45.png)



![png](output_34_46.png)



![png](output_34_47.png)



![png](output_34_48.png)



![png](output_34_49.png)



![png](output_34_50.png)



![png](output_34_51.png)



![png](output_34_52.png)



![png](output_34_53.png)



![png](output_34_54.png)



![png](output_34_55.png)



![png](output_34_56.png)



![png](output_34_57.png)



![png](output_34_58.png)



```python
#Box Cox Transformation of (highly) skewed features
skewness = skewness[abs(skewness) > 0.75]
print("There are {} skewed numerical features to Box Cox transform".format(skewness.shape[0]))

from scipy.special import boxcox1p
skewed_features = skewness.index
lam = 0.15
for feat in skewed_features:
    all_data[feat] = boxcox1p(all_data[feat], lam)
```

    There are 59 skewed numerical features to Box Cox transform



```python
for col in skewed_features:
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    plt.hist(all_data[col], bins=50)
    plt.title("Histogram of value counts for {}".format(col))
    plt.ylabel('Number of IDs')
    plt.xlabel('Occurences of value for ID')
    plt.show()
```


![png](output_36_0.png)



![png](output_36_1.png)



![png](output_36_2.png)



![png](output_36_3.png)



![png](output_36_4.png)



![png](output_36_5.png)



![png](output_36_6.png)



![png](output_36_7.png)



![png](output_36_8.png)



![png](output_36_9.png)



![png](output_36_10.png)



![png](output_36_11.png)



![png](output_36_12.png)



![png](output_36_13.png)



![png](output_36_14.png)



![png](output_36_15.png)



![png](output_36_16.png)



![png](output_36_17.png)



![png](output_36_18.png)



![png](output_36_19.png)



![png](output_36_20.png)



![png](output_36_21.png)



![png](output_36_22.png)



![png](output_36_23.png)



![png](output_36_24.png)



![png](output_36_25.png)



![png](output_36_26.png)



![png](output_36_27.png)



![png](output_36_28.png)



![png](output_36_29.png)



![png](output_36_30.png)



![png](output_36_31.png)



![png](output_36_32.png)



![png](output_36_33.png)



![png](output_36_34.png)



![png](output_36_35.png)



![png](output_36_36.png)



![png](output_36_37.png)



![png](output_36_38.png)



![png](output_36_39.png)



![png](output_36_40.png)



![png](output_36_41.png)



![png](output_36_42.png)



![png](output_36_43.png)



![png](output_36_44.png)



![png](output_36_45.png)



![png](output_36_46.png)



![png](output_36_47.png)



![png](output_36_48.png)



![png](output_36_49.png)



![png](output_36_50.png)



![png](output_36_51.png)



![png](output_36_52.png)



![png](output_36_53.png)



![png](output_36_54.png)



![png](output_36_55.png)



![png](output_36_56.png)



![png](output_36_57.png)



![png](output_36_58.png)



```python
all_data = pd.get_dummies(all_data)
print(all_data.shape)
```

    (2917, 220)



```python
# correlation after data transformation
```


```python
train = all_data[:ntrain]
test = all_data[ntrain:]
```


```python
corrmat = train.corr()
plt.subplots(figsize=(12,9))
sns.heatmap(corrmat, vmax=0.9, square=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x113a8cb50>




![png](output_40_1.png)



```python
# hard to see, please separate the feature to numeric and categorical, check the correaltion between features and target
```


```python
# for ridge/lasso, do we need to do data standardization?
# for example, for lasso, based on prediction?
```


```python
# elasticnet (http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ElasticNet.html)
# lasso
# kernelridge (http://scikit-learn.org/stable/modules/generated/sklearn.kernel_ridge.KernelRidge.html)
# gbm
# xgboost
# lightgbm (https://lightgbm.readthedocs.io/en/latest/Parameters-Tuning.html)
# ensemble and stacking
```


```python
# tunining parameter
# lasso: alpha 0.001-0.01, 
# ElasticNet: alpha: 0.001-0.01, l1_ratio:1-2
# kernel ridge:alpha: 0.1-0.3, kernel='polynomial', degree:2-4,
# gbm: n_estimators: 2000-3000, learning_rate:0.01-0.1,max_depth:4-6, max_features='sqrt',min_samples_leaf:10-20,
# min_samples_split:10－100,  loss='huber'
```


```python
# bayesian, grid serach(lasso,ridge,elasticnet, gbm)
# prediction, submission (score,ranking)
```


```python
# lasso
from sklearn.linear_model import Lasso
import sklearn.grid_search as gs
from sklearn.metrics import mean_squared_error
lasso = Lasso()
parameter_grid = {'alpha': [0.0001,0.001,0.01,0.1]}


grid_search_lasso = gs.GridSearchCV(lasso,
                           param_grid = parameter_grid,
                           scoring = 'neg_mean_squared_error',
                           cv = 5)

grid_search_lasso.fit(train.values, y_train)
print('Best score (lasso): {}'.format(grid_search_lasso.best_score_))
print('Best parameters: {}'.format(grid_search_lasso.best_params_))
```

    Best score (lasso): -0.0134423581553
    Best parameters: {'alpha': 0.001}



```python
y_train_pred_lasso = grid_search_lasso.best_estimator_.predict(train.values)
print("lasso score on training set: ", mean_squared_error( y_train, y_train_pred_lasso)**.5)
```

    ('lasso score on training set: ', 0.10738812109654973)



```python
y_test_pred_lasso = grid_search_lasso.best_estimator_.predict(test.values)
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] = np.expm1(y_test_pred_lasso)
sub_df[['ID', 'SalePrice']].to_csv('submission_lasso.csv', index= False)
```


```python
# gbm
from sklearn.ensemble import GradientBoostingRegressor
import sklearn.grid_search as gs
from sklearn.metrics import mean_squared_error
GBoost = GradientBoostingRegressor(learning_rate=0.1,max_features='sqrt',loss='huber', random_state =5)
parameter_grid = {'n_estimators': [2000,2500,3000,3500], 'max_depth': [3,4,5,6],'min_samples_leaf':[10,11,12,13],
                 'min_samples_split': [9,10,11,12]}
grid_search_GBoost = gs.GridSearchCV(GBoost,
                           param_grid = parameter_grid,
                           scoring = 'neg_mean_squared_error',
                           cv = 5)
grid_search_GBoost.fit(train.values, y_train)
print('Best score (gbm): {}'.format(grid_search_GBoost.best_score_))
print('Best parameters: {}'.format(grid_search_GBoost.best_params_))
```

    Best score (gbm): -0.0141658441682
    Best parameters: {'min_samples_split': 9, 'n_estimators': 2000, 'max_depth': 4, 'min_samples_leaf': 13}



```python
y_test_pred_GBoost= grid_search_GBoost.best_estimator_.predict(test.values)
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] = np.expm1(y_test_pred_GBoost)
sub_df[['ID', 'SalePrice']].to_csv('submission_gbm.csv', index= False)
```


```python
# kernel ridge
from sklearn.kernel_ridge import KernelRidge
KRR = KernelRidge(kernel='polynomial', coef0=5.0)
parameter_grid = {'alpha': [0.0001,0.001,0.01,0.1, 0.2], 'degree': [2,3,4]}


grid_search_KRR = gs.GridSearchCV(KRR,
                           param_grid = parameter_grid,
                           scoring = 'neg_mean_squared_error',
                           cv = 5)

grid_search_KRR.fit(train.values, y_train)
print('Best score (KRR): {}'.format(grid_search_KRR.best_score_))
print('Best parameters: {}'.format(grid_search_KRR.best_params_))

y_train_pred_KRR = grid_search_KRR.best_estimator_.predict(train.values)
print("KRR score on training set: ", mean_squared_error( y_train, y_train_pred_KRR)**.5)

y_test_pred_KRR = grid_search_KRR.best_estimator_.predict(test.values)
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] = np.expm1(y_test_pred_KRR)
sub_df[['ID', 'SalePrice']].to_csv('submission_KRR.csv', index= False)
```

    Best score (KRR): -0.0142637151298
    Best parameters: {'alpha': 0.2, 'degree': 2}
    ('KRR score on training set: ', 0.074212755997406912)



```python
# elasticnet
from sklearn.linear_model import ElasticNet
ENet = ElasticNet()
parameter_grid = {'alpha': [0.0001,0.001, 0.002,0.01,0.1, 0.2], 'l1_ratio': [0.1,0.3,0.5,0.7, 0.9,1.0]}

grid_search_ENet = gs.GridSearchCV(ENet,
                           param_grid = parameter_grid,
                           scoring = 'neg_mean_squared_error',
                           cv = 5)

grid_search_ENet.fit(train.values, y_train)
print('Best score (ENet): {}'.format(grid_search_ENet.best_score_))
print('Best parameters: {}'.format(grid_search_ENet.best_params_))

y_train_pred_ENet = grid_search_ENet.best_estimator_.predict(train.values)
print("ENet score on training set: ", mean_squared_error( y_train, y_train_pred_ENet)**.5)

y_test_pred_ENet = grid_search_ENet.best_estimator_.predict(test.values)
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] = np.expm1(y_test_pred_ENet)
sub_df[['ID', 'SalePrice']].to_csv('submission_ENet.csv', index= False)
```

    Best score (ENet): -0.012953412375
    Best parameters: {'alpha': 0.001, 'l1_ratio': 0.5}
    ('ENet score on training set: ', 0.10328645912511643)



```python
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold
import gc
from bayes_opt import BayesianOptimization
```


```python
# lightgbm
X_train=train.values
y_train=y_train
X_test=test.values
```


```python
def bayes_parameter_opt_lgb(X, y, init_round=2, opt_round=8, n_folds=5, random_seed=6, output_process=True):
    # prepare data
    train_data = lgb.Dataset(data=X, label=y,free_raw_data=False)
    # parameters
    def lgb_eval(num_leaves, colsample_bytree, subsample, max_depth, reg_lambda, reg_alpha, min_split_gain, min_child_weight, 
                min_child_sample, max_bin, subsample_freq,learning_rate):
        params = {'objective':'regression','boosting_type': 'gbdt','nthread': 4, 'verbose': -1,\
                'learning_rate':learning_rate, \
                  'early_stopping_round':50}
        params['subsample_freq']=int(round(subsample_freq))
        params['min_child_sample']=int(round(min_child_sample))
        params['max_bin']=int(round(max_bin))
        params["num_leaves"] = int(round(num_leaves))
        params['colsample_bytree'] = max(min(colsample_bytree, 1), 0)
        params['subsample'] = max(min(subsample, 1), 0)
        params['max_depth'] = int(round(max_depth))
        params['reg_lambda'] = max(reg_lambda, 0)
        params['reg_alpha'] = max(reg_alpha, 0)
        params['learning_rate'] = learning_rate
        params['min_split_gain'] = min_split_gain
        params['min_child_weight'] = min_child_weight
        cv_result = lgb.cv(params, train_data, nfold=5, num_boost_round=3000,seed=random_seed, stratified=False, verbose_eval=10, metrics=['rmse'])
        return -1.0 * np.mean(cv_result['rmse-mean'])
    # range 
    lgbBO = BayesianOptimization(lgb_eval, {'num_leaves': (5, 50),
                                            'learning_rate':(0.01, 0.1),
                                            'colsample_bytree': (0.1, 1.0),
                                            'subsample': (0.6, 1.0),
                                            'max_depth': (3, 8),
                                            'reg_lambda': (0.0, 1.0),
                                            'reg_alpha': (0.0, 1.0),
                                            'min_child_sample':(6,20),
                                            'max_bin':(30,100),
                                            'subsample_freq':(1,10),
                                            'min_split_gain': (0.1, 0.8),
                                            'min_child_weight': (3.0, 20.0)})
    # optimize
    lgbBO.maximize(init_points=init_round, n_iter=opt_round)

opt_params = bayes_parameter_opt_lgb(X_train, y_train, init_round=2, opt_round=8, n_folds=5, random_seed=6, output_process=True)
```

    [31mInitialization[0m
    [94m----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------[0m
     Step |   Time |      Value |   colsample_bytree |   learning_rate |   max_bin |   max_depth |   min_child_sample |   min_child_weight |   min_split_gain |   num_leaves |   reg_alpha |   reg_lambda |   subsample |   subsample_freq | 
    [10]	cv_agg's rmse: 0.257259 + 0.0143699
    [20]	cv_agg's rmse: 0.189019 + 0.00941624
    [30]	cv_agg's rmse: 0.160703 + 0.00701939
    [40]	cv_agg's rmse: 0.147563 + 0.00547808
    [50]	cv_agg's rmse: 0.141496 + 0.00474891
    [60]	cv_agg's rmse: 0.139048 + 0.00470601
    [70]	cv_agg's rmse: 0.138433 + 0.00459409
    [80]	cv_agg's rmse: 0.138425 + 0.00459787
    [90]	cv_agg's rmse: 0.138425 + 0.00459787
    [100]	cv_agg's rmse: 0.138425 + 0.00459787
    [110]	cv_agg's rmse: 0.138425 + 0.00459787
    [120]	cv_agg's rmse: 0.138425 + 0.00459787
        1 | 00m07s | [35m  -0.18078[0m | [32m            0.5686[0m | [32m         0.0699[0m | [32m  95.8763[0m | [32m     4.2957[0m | [32m           14.5014[0m | [32m            4.9575[0m | [32m          0.3026[0m | [32m      9.7624[0m | [32m     0.2566[0m | [32m      0.4424[0m | [32m     0.6598[0m | [32m          7.3518[0m | 
    [10]	cv_agg's rmse: 0.234921 + 0.0133581
    [20]	cv_agg's rmse: 0.175393 + 0.00944181
    [30]	cv_agg's rmse: 0.15151 + 0.00695542
    [40]	cv_agg's rmse: 0.141502 + 0.00493315
    [50]	cv_agg's rmse: 0.136703 + 0.00368062
    [60]	cv_agg's rmse: 0.135101 + 0.00332814
    [70]	cv_agg's rmse: 0.134876 + 0.00353615
    [80]	cv_agg's rmse: 0.134876 + 0.00353615
    [90]	cv_agg's rmse: 0.134876 + 0.00353615
    [100]	cv_agg's rmse: 0.134876 + 0.00353615
    [110]	cv_agg's rmse: 0.134876 + 0.00353615
        2 | 00m05s | [35m  -0.17430[0m | [32m            0.8971[0m | [32m         0.0869[0m | [32m  31.3354[0m | [32m     3.0422[0m | [32m           19.1478[0m | [32m            9.5688[0m | [32m          0.2045[0m | [32m     39.5546[0m | [32m     0.2266[0m | [32m      0.9107[0m | [32m     0.7771[0m | [32m          8.8638[0m | 
    [31mBayesian Optimization[0m
    [94m----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------[0m
     Step |   Time |      Value |   colsample_bytree |   learning_rate |   max_bin |   max_depth |   min_child_sample |   min_child_weight |   min_split_gain |   num_leaves |   reg_alpha |   reg_lambda |   subsample |   subsample_freq | 
    [10]	cv_agg's rmse: 0.217218 + 0.0108499
    [20]	cv_agg's rmse: 0.165982 + 0.00684223
    [30]	cv_agg's rmse: 0.149933 + 0.00561458
    [40]	cv_agg's rmse: 0.144245 + 0.00365821
    [50]	cv_agg's rmse: 0.143689 + 0.00347515
    [60]	cv_agg's rmse: 0.143689 + 0.00347515
    [70]	cv_agg's rmse: 0.143689 + 0.00347515
    [80]	cv_agg's rmse: 0.143689 + 0.00347515
    [90]	cv_agg's rmse: 0.143689 + 0.00347515
        3 | 00m32s |   -0.18840 |             0.7917 |          0.0990 |   78.4084 |      6.9387 |            13.6804 |             7.8494 |           0.4511 |      31.8812 |      0.3622 |       0.5255 |      0.7624 |           3.3004 | 
    [10]	cv_agg's rmse: 0.283053 + 0.0149943
    [20]	cv_agg's rmse: 0.221893 + 0.0115016
    [30]	cv_agg's rmse: 0.187317 + 0.00933382
    [40]	cv_agg's rmse: 0.167667 + 0.00702583
    [50]	cv_agg's rmse: 0.158075 + 0.00650273
    [60]	cv_agg's rmse: 0.152171 + 0.00575654
    [70]	cv_agg's rmse: 0.149046 + 0.00536913
    [80]	cv_agg's rmse: 0.148445 + 0.00519221
    [90]	cv_agg's rmse: 0.147953 + 0.00496469
    [100]	cv_agg's rmse: 0.147754 + 0.00488342
    [110]	cv_agg's rmse: 0.147457 + 0.00486701
    [120]	cv_agg's rmse: 0.147457 + 0.00486701
    [130]	cv_agg's rmse: 0.147457 + 0.00486701
    [140]	cv_agg's rmse: 0.147457 + 0.00486701
    [150]	cv_agg's rmse: 0.147457 + 0.00486701
    [160]	cv_agg's rmse: 0.147457 + 0.00486701
        4 | 00m21s |   -0.18313 |             0.1706 |          0.0652 |   98.6500 |      6.0947 |            18.0368 |             5.9554 |           0.4095 |       7.6778 |      0.8111 |       0.8657 |      0.6754 |           5.7177 | 
    [10]	cv_agg's rmse: 0.253393 + 0.013013
    [20]	cv_agg's rmse: 0.18742 + 0.00815015
    [30]	cv_agg's rmse: 0.159155 + 0.00565142
    [40]	cv_agg's rmse: 0.146861 + 0.0043222
    [50]	cv_agg's rmse: 0.141769 + 0.0036798
    [60]	cv_agg's rmse: 0.139715 + 0.00325518
    [70]	cv_agg's rmse: 0.139305 + 0.00303945
    [80]	cv_agg's rmse: 0.139305 + 0.00303945
    [90]	cv_agg's rmse: 0.139305 + 0.00303945
    [100]	cv_agg's rmse: 0.139305 + 0.00303945
    [110]	cv_agg's rmse: 0.139305 + 0.00303945
        5 | 00m18s |   -0.18171 |             0.5233 |          0.0662 |   31.8444 |      7.4074 |            10.4429 |            18.1981 |           0.3990 |      33.3239 |      0.0089 |       0.0362 |      0.7197 |           6.6379 | 
    [10]	cv_agg's rmse: 0.372968 + 0.018806
    [20]	cv_agg's rmse: 0.349123 + 0.0180184
    [30]	cv_agg's rmse: 0.327601 + 0.0169846
    [40]	cv_agg's rmse: 0.308865 + 0.0160631
    [50]	cv_agg's rmse: 0.291303 + 0.0150868
    [60]	cv_agg's rmse: 0.275707 + 0.0140706
    [70]	cv_agg's rmse: 0.261036 + 0.0132343
    [80]	cv_agg's rmse: 0.248345 + 0.0126137
    [90]	cv_agg's rmse: 0.236437 + 0.0119525
    [100]	cv_agg's rmse: 0.226535 + 0.0113632
    [110]	cv_agg's rmse: 0.217722 + 0.0107979
    [120]	cv_agg's rmse: 0.210031 + 0.0100808
    [130]	cv_agg's rmse: 0.202434 + 0.00967702
    [140]	cv_agg's rmse: 0.196298 + 0.00941308
    [150]	cv_agg's rmse: 0.190727 + 0.00926659
    [160]	cv_agg's rmse: 0.185556 + 0.00903382
    [170]	cv_agg's rmse: 0.18099 + 0.00873315
    [180]	cv_agg's rmse: 0.176911 + 0.00845012
    [190]	cv_agg's rmse: 0.172899 + 0.0081556
    [200]	cv_agg's rmse: 0.169702 + 0.00798946
    [210]	cv_agg's rmse: 0.16676 + 0.00781758
    [220]	cv_agg's rmse: 0.164024 + 0.00749282
    [230]	cv_agg's rmse: 0.16147 + 0.00739999
    [240]	cv_agg's rmse: 0.159453 + 0.00716354
    [250]	cv_agg's rmse: 0.157522 + 0.00696207
    [260]	cv_agg's rmse: 0.155831 + 0.00682709
    [270]	cv_agg's rmse: 0.154314 + 0.00668973
    [280]	cv_agg's rmse: 0.152811 + 0.00653227
    [290]	cv_agg's rmse: 0.151528 + 0.00638885
    [300]	cv_agg's rmse: 0.150372 + 0.00632014
    [310]	cv_agg's rmse: 0.149215 + 0.00615622
    [320]	cv_agg's rmse: 0.148325 + 0.00598558
    [330]	cv_agg's rmse: 0.147359 + 0.00578136
    [340]	cv_agg's rmse: 0.146663 + 0.00567849
    [350]	cv_agg's rmse: 0.146026 + 0.00557907
    [360]	cv_agg's rmse: 0.145289 + 0.00548983
    [370]	cv_agg's rmse: 0.144623 + 0.00550465
    [380]	cv_agg's rmse: 0.144174 + 0.00547549
    [390]	cv_agg's rmse: 0.143691 + 0.00539052
    [400]	cv_agg's rmse: 0.143295 + 0.005389
    [410]	cv_agg's rmse: 0.14289 + 0.00530332
    [420]	cv_agg's rmse: 0.1425 + 0.00518395
    [430]	cv_agg's rmse: 0.142209 + 0.00515256
    [440]	cv_agg's rmse: 0.141975 + 0.00517608
    [450]	cv_agg's rmse: 0.141774 + 0.00516028
    [460]	cv_agg's rmse: 0.141487 + 0.00506324
    [470]	cv_agg's rmse: 0.141245 + 0.00504227
    [480]	cv_agg's rmse: 0.141157 + 0.00502211
    [490]	cv_agg's rmse: 0.141127 + 0.00497506
    [500]	cv_agg's rmse: 0.141074 + 0.00490816
    [510]	cv_agg's rmse: 0.141074 + 0.00490816
    [520]	cv_agg's rmse: 0.141074 + 0.00490816
    [530]	cv_agg's rmse: 0.141074 + 0.00490816
    [540]	cv_agg's rmse: 0.141074 + 0.00490816
        6 | 00m39s |   -0.18759 |             0.2719 |          0.0107 |   51.2889 |      4.2017 |             8.8599 |            14.2258 |           0.3042 |      18.5551 |      0.8514 |       0.0125 |      0.6166 |           1.9358 | 
    [10]	cv_agg's rmse: 0.2425 + 0.0128724
    [20]	cv_agg's rmse: 0.179448 + 0.00828466
    [30]	cv_agg's rmse: 0.154775 + 0.0061705
    [40]	cv_agg's rmse: 0.145053 + 0.00536008
    [50]	cv_agg's rmse: 0.139639 + 0.00503024
    [60]	cv_agg's rmse: 0.136868 + 0.00429153
    [70]	cv_agg's rmse: 0.136061 + 0.00432101
    [80]	cv_agg's rmse: 0.135973 + 0.00434906
    [90]	cv_agg's rmse: 0.135973 + 0.00434906
    [100]	cv_agg's rmse: 0.135973 + 0.00434906
    [110]	cv_agg's rmse: 0.135973 + 0.00434906
    [120]	cv_agg's rmse: 0.135973 + 0.00434906
        7 | 00m18s |   -0.17464 |             0.4986 |          0.0774 |   94.2035 |      6.8388 |             9.4771 |             3.5918 |           0.1922 |      27.1090 |      0.5985 |       0.2269 |      0.8498 |           7.9054 | 
    [10]	cv_agg's rmse: 0.274256 + 0.0150232
    [20]	cv_agg's rmse: 0.210078 + 0.0109743
    [30]	cv_agg's rmse: 0.176907 + 0.00785267
    [40]	cv_agg's rmse: 0.159971 + 0.00684085
    [50]	cv_agg's rmse: 0.151472 + 0.00584287
    [60]	cv_agg's rmse: 0.147148 + 0.00499906
    [70]	cv_agg's rmse: 0.144956 + 0.00505135
    [80]	cv_agg's rmse: 0.14477 + 0.00523824
    [90]	cv_agg's rmse: 0.14477 + 0.00523824
    [100]	cv_agg's rmse: 0.14477 + 0.00523824
    [110]	cv_agg's rmse: 0.14477 + 0.00523824
    [120]	cv_agg's rmse: 0.14477 + 0.00523824
        8 | 00m30s |   -0.19114 |             0.6582 |          0.0533 |   69.4271 |      5.7720 |            12.5839 |            17.8706 |           0.6035 |      44.5132 |      0.0881 |       0.1200 |      0.8802 |           9.1782 | 
    [10]	cv_agg's rmse: 0.357569 + 0.0182159
    [20]	cv_agg's rmse: 0.321778 + 0.0168498
    [30]	cv_agg's rmse: 0.291744 + 0.0156477
    [40]	cv_agg's rmse: 0.26726 + 0.0143601
    [50]	cv_agg's rmse: 0.246191 + 0.0132667
    [60]	cv_agg's rmse: 0.229065 + 0.012242
    [70]	cv_agg's rmse: 0.214137 + 0.0111724
    [80]	cv_agg's rmse: 0.20248 + 0.0104588
    [90]	cv_agg's rmse: 0.192372 + 0.00955042
    [100]	cv_agg's rmse: 0.1843 + 0.00882438
    [110]	cv_agg's rmse: 0.177695 + 0.00838892
    [120]	cv_agg's rmse: 0.172101 + 0.00793637
    [130]	cv_agg's rmse: 0.167587 + 0.00756521
    [140]	cv_agg's rmse: 0.163454 + 0.00742715
    [150]	cv_agg's rmse: 0.160184 + 0.00697623
    [160]	cv_agg's rmse: 0.157499 + 0.00677078
    [170]	cv_agg's rmse: 0.155044 + 0.00664063
    [180]	cv_agg's rmse: 0.152913 + 0.00649774
    [190]	cv_agg's rmse: 0.151268 + 0.00623417
    [200]	cv_agg's rmse: 0.149815 + 0.0062039
    [210]	cv_agg's rmse: 0.148692 + 0.00612604
    [220]	cv_agg's rmse: 0.147775 + 0.00604534
    [230]	cv_agg's rmse: 0.147034 + 0.00598653
    [240]	cv_agg's rmse: 0.146346 + 0.00591475
    [250]	cv_agg's rmse: 0.145916 + 0.00586151
    [260]	cv_agg's rmse: 0.145909 + 0.00587053
    [270]	cv_agg's rmse: 0.145909 + 0.00587053
    [280]	cv_agg's rmse: 0.145909 + 0.00587053
    [290]	cv_agg's rmse: 0.145909 + 0.00587053
    [300]	cv_agg's rmse: 0.145909 + 0.00587053
        9 | 00m21s |   -0.19803 |             0.4059 |          0.0160 |   95.2799 |      5.0135 |             8.9293 |            18.3644 |           0.6655 |      35.3361 |      0.3936 |       0.9715 |      0.9218 |           7.4231 | 
    [10]	cv_agg's rmse: 0.280254 + 0.0150939
    [20]	cv_agg's rmse: 0.213504 + 0.0113719
    [30]	cv_agg's rmse: 0.176618 + 0.00827278
    [40]	cv_agg's rmse: 0.156738 + 0.00626898
    [50]	cv_agg's rmse: 0.145763 + 0.00553172
    [60]	cv_agg's rmse: 0.139566 + 0.00438682
    [70]	cv_agg's rmse: 0.135777 + 0.00360693
    [80]	cv_agg's rmse: 0.133708 + 0.00280056
    [90]	cv_agg's rmse: 0.131799 + 0.00261987
    [100]	cv_agg's rmse: 0.131304 + 0.00255969
    [110]	cv_agg's rmse: 0.131304 + 0.00255969
    [120]	cv_agg's rmse: 0.131304 + 0.00255969
    [130]	cv_agg's rmse: 0.131304 + 0.00255969
    [140]	cv_agg's rmse: 0.131304 + 0.00255969
    [150]	cv_agg's rmse: 0.131304 + 0.00255969
       10 | 00m16s |   -0.17531 |             0.7520 |          0.0492 |   41.9089 |      6.7951 |             9.4540 |             3.5359 |           0.1668 |      17.3097 |      0.1474 |       0.3473 |      0.7878 |           4.7886 | 



```python
train = all_data[:ntrain]
test = all_data[ntrain:]
```


```python
train.shape
```




    (1458, 220)




```python
test.shape
```




    (1459, 220)




```python
train_org = pd.read_csv('train.csv')
```


```python
train_org = train_org.drop(train_org[(train_org['GrLivArea']>4000) & (train_org['SalePrice']<300000)].index)
```


```python
train_org.shape
```




    (1458, 81)




```python
train_org["SalePrice"] = np.log1p(train_org["SalePrice"])
```


```python
y_train=train_org["SalePrice"]
```


```python
folds = KFold(n_splits=5, shuffle=True, random_state=1001)
# Create arrays and dataframes to store results
oof_preds = np.zeros(train.shape[0])
sub_preds = np.zeros(test.shape[0])
feature_importance_df = pd.DataFrame()
    
for n_fold, (train_idx, valid_idx) in enumerate(folds.split(train, y_train)):
    dtrain = lgb.Dataset(data=train.iloc[train_idx], 
                         label=y_train.iloc[train_idx],
                         free_raw_data=False)
    dvalid = lgb.Dataset(data=train.iloc[valid_idx],
                         label=y_train.iloc[valid_idx],
                         free_raw_data=False)
    params = {'boosting_type': 'gbdt',
              'objective': 'regression',
              'metric':'rmse',
              'learning_rate': 0.0869,
              'num_leaves':40, 
              'max_depth': 3,  
              'min_child_samples': 19,  
              'max_bin': 31,  
              'subsample': 0.7771,  
              'subsample_freq': 9,  
              'colsample_bytree':0.8971,  
              'min_split_gain': 0.2045,
              'min_child_weight': 9.5688 ,
              'reg_lambda': 0.9107,
              'reg_alpha': 0.2266,
              'nthread': 8,
              'verbose': -1,}
    
    clf = lgb.train(params, 
                    dtrain, 
                    valid_sets=[dtrain, dvalid], 
                    valid_names=['train','valid'],
                    num_boost_round=3000,
                    early_stopping_rounds=50,
                    verbose_eval=10)

    oof_preds[valid_idx] = clf.predict(train.iloc[valid_idx])
    sub_preds += clf.predict(test) / folds.n_splits

    fold_importance_df = pd.DataFrame()
    fold_importance_df["feature"] = train.columns
    fold_importance_df["importance"] = clf.feature_importance(importance_type='gain')
    fold_importance_df["fold"] = n_fold + 1
    feature_importance_df = pd.concat([feature_importance_df, fold_importance_df], axis=0)
    print('Fold %2d rmse : %.6f' % (n_fold + 1,mean_squared_error(y_train.iloc[valid_idx], oof_preds[valid_idx]) ** .5)) 
    del clf, dtrain, dvalid
    gc.collect()

print('Full rmse %.6f' % mean_squared_error(y_train, oof_preds)**.5)
# Write submission file and plot feature importance
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] =np.expm1(sub_preds)
sub_df[['ID', 'SalePrice']].to_csv('submission_lgb_bayesian.csv', index= False)
```

    Training until validation scores don't improve for 50 rounds.
    [10]	train's rmse: 0.228249	valid's rmse: 0.240902
    [20]	train's rmse: 0.162726	valid's rmse: 0.17792
    [30]	train's rmse: 0.133566	valid's rmse: 0.155077
    [40]	train's rmse: 0.121315	valid's rmse: 0.144059
    [50]	train's rmse: 0.116186	valid's rmse: 0.139189
    [60]	train's rmse: 0.113061	valid's rmse: 0.1363
    [70]	train's rmse: 0.113061	valid's rmse: 0.1363
    [80]	train's rmse: 0.113061	valid's rmse: 0.1363
    [90]	train's rmse: 0.113061	valid's rmse: 0.1363
    [100]	train's rmse: 0.113061	valid's rmse: 0.1363
    [110]	train's rmse: 0.113061	valid's rmse: 0.1363
    Early stopping, best iteration is:
    [60]	train's rmse: 0.113061	valid's rmse: 0.1363
    Fold  1 rmse : 0.136300
    Training until validation scores don't improve for 50 rounds.
    [10]	train's rmse: 0.22823	valid's rmse: 0.239763
    [20]	train's rmse: 0.160632	valid's rmse: 0.180729
    [30]	train's rmse: 0.132367	valid's rmse: 0.156687
    [40]	train's rmse: 0.119917	valid's rmse: 0.147146
    [50]	train's rmse: 0.113586	valid's rmse: 0.142983
    [60]	train's rmse: 0.110607	valid's rmse: 0.140445
    [70]	train's rmse: 0.110607	valid's rmse: 0.140445
    [80]	train's rmse: 0.110607	valid's rmse: 0.140445
    [90]	train's rmse: 0.110607	valid's rmse: 0.140445
    [100]	train's rmse: 0.110607	valid's rmse: 0.140445
    Early stopping, best iteration is:
    [58]	train's rmse: 0.110607	valid's rmse: 0.140445
    Fold  2 rmse : 0.140445
    Training until validation scores don't improve for 50 rounds.
    [10]	train's rmse: 0.233169	valid's rmse: 0.206965
    [20]	train's rmse: 0.167849	valid's rmse: 0.146371
    [30]	train's rmse: 0.139689	valid's rmse: 0.124995
    [40]	train's rmse: 0.12648	valid's rmse: 0.115928
    [50]	train's rmse: 0.120018	valid's rmse: 0.112733
    [60]	train's rmse: 0.116278	valid's rmse: 0.110825
    [70]	train's rmse: 0.116278	valid's rmse: 0.110825
    [80]	train's rmse: 0.116278	valid's rmse: 0.110825
    [90]	train's rmse: 0.116278	valid's rmse: 0.110825
    [100]	train's rmse: 0.116278	valid's rmse: 0.110825
    Early stopping, best iteration is:
    [59]	train's rmse: 0.116278	valid's rmse: 0.110825
    Fold  3 rmse : 0.110825
    Training until validation scores don't improve for 50 rounds.
    [10]	train's rmse: 0.23056	valid's rmse: 0.252931
    [20]	train's rmse: 0.161611	valid's rmse: 0.191396
    [30]	train's rmse: 0.131078	valid's rmse: 0.16371
    [40]	train's rmse: 0.117501	valid's rmse: 0.151887
    [50]	train's rmse: 0.110937	valid's rmse: 0.146291
    [60]	train's rmse: 0.108966	valid's rmse: 0.144511
    [70]	train's rmse: 0.108966	valid's rmse: 0.144511
    [80]	train's rmse: 0.108966	valid's rmse: 0.144511
    [90]	train's rmse: 0.108966	valid's rmse: 0.144511
    [100]	train's rmse: 0.108966	valid's rmse: 0.144511
    Early stopping, best iteration is:
    [57]	train's rmse: 0.108966	valid's rmse: 0.144511
    Fold  4 rmse : 0.144511
    Training until validation scores don't improve for 50 rounds.
    [10]	train's rmse: 0.229448	valid's rmse: 0.242787
    [20]	train's rmse: 0.162236	valid's rmse: 0.181455
    [30]	train's rmse: 0.132152	valid's rmse: 0.158295
    [40]	train's rmse: 0.118627	valid's rmse: 0.147515
    [50]	train's rmse: 0.113109	valid's rmse: 0.143767
    [60]	train's rmse: 0.112451	valid's rmse: 0.143466
    [70]	train's rmse: 0.112451	valid's rmse: 0.143466
    [80]	train's rmse: 0.112451	valid's rmse: 0.143466
    [90]	train's rmse: 0.112451	valid's rmse: 0.143466
    [100]	train's rmse: 0.112451	valid's rmse: 0.143466
    Early stopping, best iteration is:
    [53]	train's rmse: 0.112451	valid's rmse: 0.143466
    Fold  5 rmse : 0.143466
    Full rmse 0.135672



```python
# feature importance
cols = feature_importance_df[["feature", "importance"]].groupby("feature").mean().sort_values(by="importance", ascending=False)[:40].index
best_features = feature_importance_df.loc[feature_importance_df.feature.isin(cols)]
plt.figure(figsize=(8, 10))
sns.barplot(x="importance", y="feature", data=best_features.sort_values(by="importance", ascending=False))
plt.title('LightGBM Features (avg over folds)')
plt.tight_layout
plt.show()
```


![png](output_65_0.png)



```python
import gc
import time
from sklearn.model_selection import KFold, StratifiedKFold
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import xgboost as xgb
from sklearn import metrics
from sklearn.metrics import mean_squared_error
from bayes_opt import BayesianOptimization
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test)
```


```python
def xgb_evaluate(max_depth, subsample,gamma, colsample_bytree, max_leaves,max_bin, min_child_weight,colsample_bylevel,\
                reg_alpha,reg_lambda,eta,n_estimators ):
    params = {'eval_metric': 'rmse',\
              'objective': 'reg:linear',\
              'booster':'gbtree',\
              'max_depth': int(max_depth),\
              'n_estimators':int(n_estimators),
              'subsample': subsample,\
              'eta': eta,\
              'gamma': gamma,\
              'colsample_bytree': colsample_bytree,\
             'max_leaves': int(max_leaves),\
              'max_bin':int(max_bin),\
              'min_child_weight':min_child_weight,\
              'colsample_bylevel':colsample_bylevel,\
              'reg_alpha':reg_alpha,\
              'reg_lambda':reg_lambda}
    cv_result = xgb.cv(params, dtrain, nfold=5)    
    # Bayesian optimization only knows how to maximize, not minimize, so return the negative RMSE
    return -1.0 * cv_result['test-rmse-mean'].iloc[-1]
```


```python
xgb_bo = BayesianOptimization(xgb_evaluate, {'max_depth': (3, 8), \
                                             'eta':(0.01, 0.1),\
                                             'gamma': (0, 1),\
                                             'subsample': (0.5, 1.0),\
                                            'max_leaves': (10, 100),\
                                             'n_estimators':(2000,3000),\
                                            'colsample_bytree': (0.4, 1.0),\
                                            'reg_lambda': (0, 1),\
                                            'reg_alpha': (0, 1),\
                                            'max_bin':(30,100),\
                                            'colsample_bylevel':(0.6,1.0),\
                                            'min_child_weight': (1, 10)})
# Use the expected improvement acquisition function to handle negative numbers
xgb_bo.maximize(init_points=3, n_iter=7, acq='ei')
```

    [31mInitialization[0m
    [94m--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------[0m
     Step |   Time |      Value |   colsample_bylevel |   colsample_bytree |       eta |     gamma |   max_bin |   max_depth |   max_leaves |   min_child_weight |   n_estimators |   reg_alpha |   reg_lambda |   subsample | 
        1 | 00m00s | [35m  -9.72334[0m | [32m             0.6965[0m | [32m            0.9178[0m | [32m   0.0169[0m | [32m   0.9590[0m | [32m  78.7586[0m | [32m     4.5635[0m | [32m     70.6153[0m | [32m            4.8103[0m | [32m     2612.9951[0m | [32m     0.7010[0m | [32m      0.3807[0m | [32m     0.6756[0m | 
        2 | 00m01s | [35m  -8.74465[0m | [32m             0.8698[0m | [32m            0.5243[0m | [32m   0.0273[0m | [32m   0.1456[0m | [32m  54.9240[0m | [32m     4.7796[0m | [32m     49.6354[0m | [32m            4.2784[0m | [32m     2091.5331[0m | [32m     0.7201[0m | [32m      0.0629[0m | [32m     0.9922[0m | 
        3 | 00m00s |   -9.40560 |              0.7598 |             0.5493 |    0.0202 |    0.2032 |   93.6335 |      4.2971 |      35.0698 |             9.2235 |      2739.2377 |      0.4374 |       0.3309 |      0.8315 | 
    [31mBayesian Optimization[0m
    [94m--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------[0m
     Step |   Time |      Value |   colsample_bylevel |   colsample_bytree |       eta |     gamma |   max_bin |   max_depth |   max_leaves |   min_child_weight |   n_estimators |   reg_alpha |   reg_lambda |   subsample | 
        4 | 00m31s | [35m  -7.04685[0m | [32m             0.6636[0m | [32m            0.6337[0m | [32m   0.0482[0m | [32m   0.4806[0m | [32m  71.0314[0m | [32m     4.6961[0m | [32m     98.9566[0m | [32m            4.9857[0m | [32m     2397.7298[0m | [32m     0.4728[0m | [32m      0.9628[0m | [32m     0.6088[0m | 
        5 | 00m15s |   -9.22031 |              0.6630 |             0.6332 |    0.0222 |    0.4805 |   71.0314 |      4.6960 |      98.9566 |             4.9857 |      2397.7298 |      0.4718 |       0.9627 |      0.6085 | 
        6 | 00m16s |   -8.45284 |              0.7173 |             0.9730 |    0.0306 |    0.6959 |   69.5713 |      4.0858 |      10.4041 |             5.2684 |      2264.2043 |      0.7967 |       0.3424 |      0.6472 | 
        7 | 00m27s |  -10.34195 |              0.6629 |             0.6333 |    0.0108 |    0.4805 |   71.0314 |      4.6960 |      98.9566 |             4.9857 |      2397.7298 |      0.4719 |       0.9627 |      0.6085 | 
        8 | 05m16s |  -10.43091 |              0.6632 |             0.6336 |    0.0100 |    0.4806 |   71.0314 |      4.6961 |      98.9566 |             4.9417 |      2397.7298 |      0.4725 |       0.9628 |      0.6087 | 
        9 | 03m15s | [35m  -6.68064[0m | [32m             0.6622[0m | [32m            0.6293[0m | [32m   0.0533[0m | [32m   0.4726[0m | [32m  70.8598[0m | [32m     4.6976[0m | [32m     99.2509[0m | [32m            5.1225[0m | [32m     2396.3122[0m | [32m     0.4689[0m | [32m      0.9721[0m | [32m     0.6077[0m | 
       10 | 03m01s | [35m  -6.53395[0m | [32m             0.6574[0m | [32m            0.6365[0m | [32m   0.0554[0m | [32m   0.5157[0m | [32m  72.1795[0m | [32m     4.6988[0m | [32m     96.8623[0m | [32m            5.4760[0m | [32m     2396.6638[0m | [32m     0.4690[0m | [32m      0.9256[0m | [32m     0.6062[0m | 



```python
train = all_data[:ntrain]
test = all_data[ntrain:]
train_org = pd.read_csv('train.csv')
train_org = train_org.drop(train_org[(train_org['GrLivArea']>4000) & (train_org['SalePrice']<300000)].index)
train_org["SalePrice"] = np.log1p(train_org["SalePrice"])
y_train=train_org["SalePrice"]
```


```python
folds = KFold(n_splits= 5, shuffle=True, random_state=1001)
    # Create arrays and dataframes to store results
oof_preds = np.zeros(train.shape[0])
sub_preds = np.zeros(test.shape[0])
feature_importance_df = pd.DataFrame()
dtest=xgb.DMatrix(test)
    
for n_fold, (train_idx, valid_idx) in enumerate(folds.split(train, y_train)):
    dtrain = xgb.DMatrix(train.iloc[train_idx],y_train.iloc[train_idx])
    dvalid = xgb.DMatrix(train.iloc[valid_idx], y_train.iloc[valid_idx])
    valid_y=y_train.iloc[valid_idx]

       # xgb
    params = {'eval_metric': 'rmse',
              'objective': 'reg:linear',
              'booster':'gbtree',
              #'tree_method': 'auto',
              'nthread' : 4,
              'eta' : 0.0554,
              'max_leaves': 97,
              'max_depth' : 5,
              'max_bin': 72,
              'min_child_weight' : 5.4760,
              'subsample' :0.6062,
              'colsample_bytree' :0.6365,
              'colsample_bylevel' : 0.6574,
              'reg_alpha' : 0.4690,
              'reg_lambda' : 0.9256,
              'gamma':0.5157}
    watchlist = [(dtrain, 'train'), (dvalid, 'valid')]
        
    model=xgb.train(params, dtrain, 2400, watchlist, maximize=False, early_stopping_rounds = 50, verbose_eval=10)
    oof_preds[valid_idx] = model.predict(dvalid, ntree_limit=model.best_ntree_limit)
    sub_preds += model.predict(dtest,ntree_limit=model.best_ntree_limit) / folds.n_splits

    fold_importance_df = pd.DataFrame()
    fold_importance_df = pd.DataFrame(model.get_fscore().items(), columns=['feature','importance']).sort_values('importance', ascending=False)
    fold_importance_df["fold"] = n_fold + 1
    feature_importance_df = pd.concat([feature_importance_df, fold_importance_df], axis=0)
    print('Fold %2d rmse : %.6f' % (n_fold + 1,mean_squared_error(valid_y, oof_preds[valid_idx]) ** .5)) 
    del model, dtrain, dvalid
    gc.collect()

print('Full rmse %.6f' % mean_squared_error(y_train, oof_preds)**.5)
sub_df = pd.DataFrame(np.array(test_ID), columns=['ID'])
sub_df['SalePrice'] = np.expm1(sub_preds)
sub_df[['ID', 'SalePrice']].to_csv('submission_xgb_bayesian.csv', index= False)
```

    [0]	train-rmse:10.8925	valid-rmse:10.8959
    Multiple eval metrics have been passed: 'valid-rmse' will be used for early stopping.
    
    Will train until valid-rmse hasn't improved in 50 rounds.
    [10]	train-rmse:6.17111	valid-rmse:6.17624
    [20]	train-rmse:3.50519	valid-rmse:3.50987
    [30]	train-rmse:1.99689	valid-rmse:2.00268
    [40]	train-rmse:1.14356	valid-rmse:1.14519
    [50]	train-rmse:0.664776	valid-rmse:0.664617
    [60]	train-rmse:0.398063	valid-rmse:0.397829
    [70]	train-rmse:0.255505	valid-rmse:0.258819
    [80]	train-rmse:0.184161	valid-rmse:0.190566
    [90]	train-rmse:0.151896	valid-rmse:0.161541
    [100]	train-rmse:0.138322	valid-rmse:0.149843
    [110]	train-rmse:0.133473	valid-rmse:0.145764
    [120]	train-rmse:0.131013	valid-rmse:0.143296
    [130]	train-rmse:0.130117	valid-rmse:0.142749
    [140]	train-rmse:0.129524	valid-rmse:0.142043
    [150]	train-rmse:0.129001	valid-rmse:0.141658
    [160]	train-rmse:0.128768	valid-rmse:0.141522
    [170]	train-rmse:0.128546	valid-rmse:0.141392
    [180]	train-rmse:0.128545	valid-rmse:0.141411
    [190]	train-rmse:0.128545	valid-rmse:0.141417
    [200]	train-rmse:0.128313	valid-rmse:0.141167
    [210]	train-rmse:0.127846	valid-rmse:0.140749
    [220]	train-rmse:0.127624	valid-rmse:0.140481
    [230]	train-rmse:0.127625	valid-rmse:0.140461
    [240]	train-rmse:0.127625	valid-rmse:0.140462
    [250]	train-rmse:0.127624	valid-rmse:0.140476
    [260]	train-rmse:0.127624	valid-rmse:0.140483
    [270]	train-rmse:0.127625	valid-rmse:0.140471
    [280]	train-rmse:0.127102	valid-rmse:0.140084
    [290]	train-rmse:0.127101	valid-rmse:0.140094
    [300]	train-rmse:0.126869	valid-rmse:0.139835
    [310]	train-rmse:0.126869	valid-rmse:0.139831
    [320]	train-rmse:0.126869	valid-rmse:0.13983
    [330]	train-rmse:0.12687	valid-rmse:0.139821
    [340]	train-rmse:0.12687	valid-rmse:0.139823
    [350]	train-rmse:0.126868	valid-rmse:0.13985
    [360]	train-rmse:0.126869	valid-rmse:0.139863
    [370]	train-rmse:0.126211	valid-rmse:0.139143
    [380]	train-rmse:0.126211	valid-rmse:0.13914
    [390]	train-rmse:0.126211	valid-rmse:0.139142
    [400]	train-rmse:0.126211	valid-rmse:0.139135
    [410]	train-rmse:0.126211	valid-rmse:0.139126
    [420]	train-rmse:0.126212	valid-rmse:0.139117
    [430]	train-rmse:0.126212	valid-rmse:0.139159
    [440]	train-rmse:0.125771	valid-rmse:0.138753
    [450]	train-rmse:0.125771	valid-rmse:0.138759
    [460]	train-rmse:0.125771	valid-rmse:0.138751
    [470]	train-rmse:0.125772	valid-rmse:0.138741
    [480]	train-rmse:0.125772	valid-rmse:0.138764
    [490]	train-rmse:0.125771	valid-rmse:0.138746
    [500]	train-rmse:0.125771	valid-rmse:0.138762
    [510]	train-rmse:0.125772	valid-rmse:0.138774
    [520]	train-rmse:0.125773	valid-rmse:0.13878
    [530]	train-rmse:0.125771	valid-rmse:0.138755
    Stopping. Best iteration:
    [488]	train-rmse:0.125772	valid-rmse:0.138736
    
    Fold  1 rmse : 0.138736
    [0]	train-rmse:10.8888	valid-rmse:10.9148
    Multiple eval metrics have been passed: 'valid-rmse' will be used for early stopping.
    
    Will train until valid-rmse hasn't improved in 50 rounds.
    [10]	train-rmse:6.1722	valid-rmse:6.19667
    [20]	train-rmse:3.50714	valid-rmse:3.52523
    [30]	train-rmse:1.99709	valid-rmse:2.01017
    [40]	train-rmse:1.14511	valid-rmse:1.15645
    [50]	train-rmse:0.66418	valid-rmse:0.677583
    [60]	train-rmse:0.397644	valid-rmse:0.412811
    [70]	train-rmse:0.254999	valid-rmse:0.272219
    [80]	train-rmse:0.183466	valid-rmse:0.202006
    [90]	train-rmse:0.15165	valid-rmse:0.170347
    [100]	train-rmse:0.139047	valid-rmse:0.157002
    [110]	train-rmse:0.132962	valid-rmse:0.151164
    [120]	train-rmse:0.130305	valid-rmse:0.148183
    [130]	train-rmse:0.12965	valid-rmse:0.147268
    [140]	train-rmse:0.129019	valid-rmse:0.146555
    [150]	train-rmse:0.128974	valid-rmse:0.146381
    [160]	train-rmse:0.128452	valid-rmse:0.145819
    [170]	train-rmse:0.12801	valid-rmse:0.14524
    [180]	train-rmse:0.127505	valid-rmse:0.144834
    [190]	train-rmse:0.127245	valid-rmse:0.14458
    [200]	train-rmse:0.12674	valid-rmse:0.144112
    [210]	train-rmse:0.126493	valid-rmse:0.143787
    [220]	train-rmse:0.126493	valid-rmse:0.143773
    [230]	train-rmse:0.126493	valid-rmse:0.143752
    [240]	train-rmse:0.126111	valid-rmse:0.143428
    [250]	train-rmse:0.126111	valid-rmse:0.143451
    [260]	train-rmse:0.126111	valid-rmse:0.143437
    [270]	train-rmse:0.126112	valid-rmse:0.143498
    [280]	train-rmse:0.126111	valid-rmse:0.143466
    [290]	train-rmse:0.126111	valid-rmse:0.14345
    [300]	train-rmse:0.126111	valid-rmse:0.143456
    Stopping. Best iteration:
    [256]	train-rmse:0.126113	valid-rmse:0.143393
    
    Fold  2 rmse : 0.143393
    [0]	train-rmse:10.8956	valid-rmse:10.8919
    Multiple eval metrics have been passed: 'valid-rmse' will be used for early stopping.
    
    Will train until valid-rmse hasn't improved in 50 rounds.
    [10]	train-rmse:6.17528	valid-rmse:6.17118
    [20]	train-rmse:3.50489	valid-rmse:3.50492
    [30]	train-rmse:1.99697	valid-rmse:1.99495
    [40]	train-rmse:1.14499	valid-rmse:1.14367
    [50]	train-rmse:0.666149	valid-rmse:0.662078
    [60]	train-rmse:0.400447	valid-rmse:0.394809
    [70]	train-rmse:0.257171	valid-rmse:0.249301
    [80]	train-rmse:0.185707	valid-rmse:0.174659
    [90]	train-rmse:0.153815	valid-rmse:0.140484
    [100]	train-rmse:0.138703	valid-rmse:0.124771
    [110]	train-rmse:0.133331	valid-rmse:0.118824
    [120]	train-rmse:0.130729	valid-rmse:0.116214
    [130]	train-rmse:0.130064	valid-rmse:0.115337
    [140]	train-rmse:0.128959	valid-rmse:0.114617
    [150]	train-rmse:0.128135	valid-rmse:0.114322
    [160]	train-rmse:0.12757	valid-rmse:0.114007
    [170]	train-rmse:0.127553	valid-rmse:0.113921
    [180]	train-rmse:0.127548	valid-rmse:0.113878
    [190]	train-rmse:0.127547	valid-rmse:0.113858
    [200]	train-rmse:0.127314	valid-rmse:0.113669
    [210]	train-rmse:0.127313	valid-rmse:0.113652
    [220]	train-rmse:0.127105	valid-rmse:0.11371
    [230]	train-rmse:0.127103	valid-rmse:0.113669
    [240]	train-rmse:0.126609	valid-rmse:0.113424
    [250]	train-rmse:0.126609	valid-rmse:0.11341
    [260]	train-rmse:0.126609	valid-rmse:0.113422
    [270]	train-rmse:0.126609	valid-rmse:0.11343
    [280]	train-rmse:0.126609	valid-rmse:0.11342
    [290]	train-rmse:0.12661	valid-rmse:0.113439
    [300]	train-rmse:0.126392	valid-rmse:0.113401
    [310]	train-rmse:0.12595	valid-rmse:0.113137
    [320]	train-rmse:0.12595	valid-rmse:0.113134
    [330]	train-rmse:0.125949	valid-rmse:0.113087
    [340]	train-rmse:0.12595	valid-rmse:0.113067
    [350]	train-rmse:0.125949	valid-rmse:0.113104
    [360]	train-rmse:0.125949	valid-rmse:0.113084
    [370]	train-rmse:0.125949	valid-rmse:0.113084
    [380]	train-rmse:0.12595	valid-rmse:0.113073
    [390]	train-rmse:0.125951	valid-rmse:0.113059
    [400]	train-rmse:0.125949	valid-rmse:0.113093
    [410]	train-rmse:0.125949	valid-rmse:0.113084
    [420]	train-rmse:0.12595	valid-rmse:0.113071
    [430]	train-rmse:0.125949	valid-rmse:0.113101
    [440]	train-rmse:0.125491	valid-rmse:0.112747
    [450]	train-rmse:0.125491	valid-rmse:0.112754
    [460]	train-rmse:0.125492	valid-rmse:0.112729
    [470]	train-rmse:0.125491	valid-rmse:0.112736
    [480]	train-rmse:0.125491	valid-rmse:0.112741
    [490]	train-rmse:0.125494	valid-rmse:0.112819
    [500]	train-rmse:0.125493	valid-rmse:0.112815
    [510]	train-rmse:0.125491	valid-rmse:0.112781
    Stopping. Best iteration:
    [463]	train-rmse:0.125494	valid-rmse:0.112714
    
    Fold  3 rmse : 0.112714
    [0]	train-rmse:10.8917	valid-rmse:10.8979
    Multiple eval metrics have been passed: 'valid-rmse' will be used for early stopping.
    
    Will train until valid-rmse hasn't improved in 50 rounds.
    [10]	train-rmse:6.17383	valid-rmse:6.18038
    [20]	train-rmse:3.50706	valid-rmse:3.50987
    [30]	train-rmse:1.99846	valid-rmse:2.00065
    [40]	train-rmse:1.14593	valid-rmse:1.14858
    [50]	train-rmse:0.666178	valid-rmse:0.6699
    [60]	train-rmse:0.398962	valid-rmse:0.405289
    [70]	train-rmse:0.256501	valid-rmse:0.266596
    [80]	train-rmse:0.185583	valid-rmse:0.201563
    [90]	train-rmse:0.153086	valid-rmse:0.173305
    [100]	train-rmse:0.137879	valid-rmse:0.16138
    [110]	train-rmse:0.132681	valid-rmse:0.158018
    [120]	train-rmse:0.130423	valid-rmse:0.156621
    [130]	train-rmse:0.128963	valid-rmse:0.155662
    [140]	train-rmse:0.128409	valid-rmse:0.155562
    [150]	train-rmse:0.128357	valid-rmse:0.155669
    [160]	train-rmse:0.128105	valid-rmse:0.155381
    [170]	train-rmse:0.127869	valid-rmse:0.155242
    [180]	train-rmse:0.127391	valid-rmse:0.154831
    [190]	train-rmse:0.12719	valid-rmse:0.154556
    [200]	train-rmse:0.12719	valid-rmse:0.154549
    [210]	train-rmse:0.127191	valid-rmse:0.154539
    [220]	train-rmse:0.127191	valid-rmse:0.154538
    [230]	train-rmse:0.127189	valid-rmse:0.154622
    [240]	train-rmse:0.127189	valid-rmse:0.154622
    [250]	train-rmse:0.127189	valid-rmse:0.154607
    Stopping. Best iteration:
    [209]	train-rmse:0.127192	valid-rmse:0.154527
    
    Fold  4 rmse : 0.154527
    [0]	train-rmse:10.8996	valid-rmse:10.8675
    Multiple eval metrics have been passed: 'valid-rmse' will be used for early stopping.
    
    Will train until valid-rmse hasn't improved in 50 rounds.
    [10]	train-rmse:6.17831	valid-rmse:6.14679
    [20]	train-rmse:3.50894	valid-rmse:3.48487
    [30]	train-rmse:1.99999	valid-rmse:1.98326
    [40]	train-rmse:1.14464	valid-rmse:1.13318
    [50]	train-rmse:0.665152	valid-rmse:0.660683
    [60]	train-rmse:0.397303	valid-rmse:0.398003
    [70]	train-rmse:0.254411	valid-rmse:0.260645
    [80]	train-rmse:0.182269	valid-rmse:0.194265
    [90]	train-rmse:0.149802	valid-rmse:0.166134
    [100]	train-rmse:0.135241	valid-rmse:0.154567
    [110]	train-rmse:0.130025	valid-rmse:0.150138
    [120]	train-rmse:0.127885	valid-rmse:0.148541
    [130]	train-rmse:0.126527	valid-rmse:0.147548
    [140]	train-rmse:0.12535	valid-rmse:0.147123
    [150]	train-rmse:0.125003	valid-rmse:0.146795
    [160]	train-rmse:0.124482	valid-rmse:0.14671
    [170]	train-rmse:0.124226	valid-rmse:0.146776
    [180]	train-rmse:0.123506	valid-rmse:0.146497
    [190]	train-rmse:0.123001	valid-rmse:0.145916
    [200]	train-rmse:0.122581	valid-rmse:0.14566
    [210]	train-rmse:0.122582	valid-rmse:0.145658
    [220]	train-rmse:0.122581	valid-rmse:0.14566
    [230]	train-rmse:0.122579	valid-rmse:0.145665
    [240]	train-rmse:0.122578	valid-rmse:0.145667
    [250]	train-rmse:0.122579	valid-rmse:0.145666
    [260]	train-rmse:0.122578	valid-rmse:0.145674
    Stopping. Best iteration:
    [216]	train-rmse:0.122584	valid-rmse:0.145656
    
    Fold  5 rmse : 0.145655
    Full rmse 0.139705



```python
# feature importance
cols = feature_importance_df[["feature", "importance"]].groupby("feature").mean().sort_values(by="importance", ascending=False)[:40].index
best_features = feature_importance_df.loc[feature_importance_df.feature.isin(cols)]
plt.figure(figsize=(8, 10))
sns.barplot(x="importance", y="feature", data=best_features.sort_values(by="importance", ascending=False))
plt.title('LightGBM Features (avg over folds)')
plt.tight_layout
plt.show()
```


![png](output_71_0.png)



```python

```
